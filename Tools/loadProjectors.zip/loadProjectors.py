# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# Load Projectors
# coding: utf-8
# Written by Jorel Latraille
# ------------------------------------------------------------------------------
# DISCLAIMER & TERMS OF USE:
#
# Copyright (c) The Foundry 2014.
# All rights reserved.
#
# This software is provided as-is with use in commercial projects permitted.
# Redistribution in commercial projects is also permitted
# provided that the above copyright notice and this paragraph are
# duplicated in accompanying documentation,
# and acknowledge that the software was developed
# by The Foundry.  The name of the
# The Foundry may not be used to endorse or promote products derived
# from this software without specific prior written permission.
# THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------

import mari
import os
from PySide import QtGui

# ------------------------------------------------------------------------------
class LoadProjectorsUI(QtGui.QDialog):
    "Create Load Projectors UI"
    def __init__(self, parent=None):
        super(LoadProjectorsUI, self).__init__(parent)

        #Set title and create the major layouts
        self.setWindowTitle('Load Projectors')
        main_layout = QtGui.QVBoxLayout()
        projectors_path_layout = QtGui.QHBoxLayout()
        path_layout = QtGui.QHBoxLayout()
        button_layout = QtGui.QHBoxLayout()

        path_pixmap = QtGui.QPixmap(mari.resources.path(mari.resources.ICONS) + '/ImportImages.png')
        icon = QtGui.QIcon(path_pixmap)

        #Create projectors path line input and button
        projectors_path_label = QtGui.QLabel("Projectors Directory:")
        self.projectors_path = QtGui.QLineEdit()
        self.projectors_path.setMinimumWidth(600)
        projectors_path_button = QtGui.QPushButton(icon, "")
        projectors_path_button.clicked.connect(self._getProjectorsPath)

        projectors_path_layout.addWidget(projectors_path_label)
        projectors_path_layout.addWidget(self.projectors_path)
        projectors_path_layout.addWidget(projectors_path_button)

        #Create image path line input and button
        path_label = QtGui.QLabel('Images Directory:')
        self.images_path = QtGui.QLineEdit()
        images_path_button = QtGui.QPushButton(icon, "")
        images_path_button.clicked.connect(self._getImagesPath)

        #Add path widgets to path_layout
        path_layout.addWidget(path_label)
        path_layout.addWidget(self.images_path)
        path_layout.addWidget(images_path_button)

        #Create buttons and hook them up
        ok = QtGui.QPushButton('&OK')
        cancel = QtGui.QPushButton('&Cancel')
        ok.clicked.connect(self._accepted)
        cancel.clicked.connect(self.reject)

        #Add buttons to button_layout
        button_layout.addWidget(ok)
        button_layout.addWidget(cancel)

        #Add layouts to dialog
        main_layout.addLayout(projectors_path_layout)
        main_layout.addLayout(path_layout)
        main_layout.addLayout(button_layout)
        self.setLayout(main_layout)

        # #Keep dialog on top
        # self.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint)

    def _getProjectorsPath(self):
        "Get file path and set the text in path LineEdit widget"
        file_path = QtGui.QFileDialog.getExistingDirectory(None,"Projector path")
        if file_path == "":
            return
        else:
            self.projectors_path.setText(file_path)

    def _getImagesPath(self):
        "Get file path and set the text in path LineEdit widget"
        file_path = QtGui.QFileDialog.getExistingDirectory(None,"Images path")
        if file_path == "":
            return
        else:
            self.images_path.setText(file_path)

    def _accepted(self):
        "Check file path provided exists"
        if not os.path.isdir(self.projectors_path.text()) or not os.path.isdir(self.images_path.text()):
            return
        self.accept()


# ------------------------------------------------------------------------------
def loadProjectors():
    "Load projectors and their associated images from the provided paths"
    dialog = LoadProjectorsUI()
    if not dialog.exec_():
        return

    mari.app.setActiveTab("Forums")
    pmode = mari.projection.getProperty('Projection/bakeBehavior')
    mari.projection.setProperty('Projection/bakeBehavior', 'AutoBakeAndClear')

    fileTypes = (".abc", ".fbx", ".mpr")

    projectorsPath = dialog.projectors_path.text()
    imagesPath = dialog.images_path.text()

    # Get all the images in the provided path
    imagePaths = [os.path.join(imagesPath, imageFile) for imageFile in os.listdir(imagesPath) if imageFile.endswith(tuple(mari.images.supportedReadFormats()))]

    # Start loading the projectors and images
    for projectorFile in os.listdir(projectorsPath):
        if not projectorFile.endswith(fileTypes):
            continue

        channel = mari.current.channel()

        projectorName = os.path.splitext(projectorFile)[0]
        projector = mari.projectors.load(os.path.join(projectorsPath, projectorFile))[0]
        projector.setName("%s" %projectorName)
        mari.projectors.setCurrent(projector)

        # Create the layer
        layer = channel.createPaintableLayer("%s" %projectorName)
        channel.setCurrentLayer(layer)

        found = False
        for imagePath in imagePaths:
            if projectorName in imagePath:
                found = True
                break

        if found:
            projector.importFromFile(imagePath)
            projector.project()
            mari.canvases.paintBuffer().bakeAndClear()
            found = False

        layer.makeMask()

    mari.projection.setProperty('Projection/bakeBehavior', pmode)

# ------------------------------------------------------------------------------
# Add action to Mari menu.
action = mari.actions.create(
    "Load Projectors", "loadProjectors()"
    )
mari.menus.addAction(action, "MainWindow/Scripts/Camera")
icon_filename = "LoadProjector.png"
icon_path = mari.resources.path(mari.resources.ICONS) + "/" + icon_filename
action.setIconPath(icon_path)