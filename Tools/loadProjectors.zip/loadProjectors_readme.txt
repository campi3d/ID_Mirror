# ------------------------------------------------------------------------------
# Load Projectors
# coding: utf-8
# Written by Jorel Latraille
# ------------------------------------------------------------------------------



Install:
Put loadProjectors.py into your Mari script directory.
A new Item 'Load Projectors' will appear in Mari in the /Scripts/Camera/ Menu

Usage:
The Scripts will load all projectors from a directory and associated images from another directory and project.
It's based off of file name, so each projector has to have a unique file name with an associated image, eg:

/projectors/1001_proj.abc
/projectors/1002_proj.abc

/images/1001_proj.tif
/images/1002_proj.tif







# ------------------------------------------------------------------------------
# DISCLAIMER & TERMS OF USE:
#
# Copyright (c) The Foundry 2014.
# All rights reserved.
#
# This software is provided as-is with use in commercial projects permitted.
# Redistribution in commercial projects is also permitted
# provided that the above copyright notice and this paragraph are
# duplicated in accompanying documentation,
# and acknowledge that the software was developed
# by The Foundry.  The name of the
# The Foundry may not be used to endorse or promote products derived
# from this software without specific prior written permission.
# THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
# ------------------------------------------------------------------------------
