#Clear Selected Patches v0.3
#Script by Orlando Esponda orlando.esponda@gmail.com
#DISCLAIMER & TERMS OF USE

#This script is being provided as is. While the Author may choose to provide support for it, he is not responsible for any loss of data that may occur as a direct result of its usage.
#This script is privately developed. The Foundry and mari.ideascale.com are not responsible for its content.

#This script may be modified to your needs, however it may not be re-released without prior written consent by the author Orlando Esponda.


import mari
import PythonQt

gui = PythonQt.QtGui
core = PythonQt.QtCore

channelSelection_window = None
currentChannel_button = None

fillTransparent = mari.actions.get('/Mari/Layers/Fill/Transparent')
fillBlack = mari.actions.get('/Mari/Layers/Fill/Black')
flattenMaskGroup = mari.actions.get('/Mari/Layers/Flatten Mask Group')


# -----------------------------------------------------------------------------
def main_exec(selectedPatches, channel_list):
    """Main exec function"""

    if len(selectedPatches) < 1:
        mari.utils.message("Please select at least one patch and try again.")
    else:
        for channel in channel_list:
            print "\n** channel %s **" % channel.name()
            getLayer(channel.layerList())


# -----------------------------------------------------------------------------
def clearPatchesDialog():
    #Create main dialog, add main layout and set title
    global channelSelection_window
    channelSelection_window = gui.QDialog()
    channelSelection_layout = gui.QVBoxLayout()
    channelSelection_window.setLayout(channelSelection_layout)
    channelSelection_window.setWindowTitle("Clear Selected Patches")

    #Create browse layout and add widgets
    global currentChannel_button
    applyTo_label = gui.QLabel("Apply to:")
    currentChannel_button = gui.QRadioButton("Current Channel")
    currentChannel_button.setChecked(True)
    allChannels_button = gui.QRadioButton("All Channels")
    channelSelection_layout.addWidget(applyTo_label)
    channelSelection_layout.addWidget(currentChannel_button)
    channelSelection_layout.addWidget(allChannels_button)

    #Add Ok and Cancel buttons layout
    buttons_layout = gui.QHBoxLayout()
    main_ok_button = gui.QPushButton("OK")
    main_cancel_button = gui.QPushButton("Cancel")
    main_ok_button.connect("clicked()", lambda: clickedOKchanSel(channelSelection_window))
    main_cancel_button.connect("clicked()", channelSelection_window.reject)

    buttons_layout.addWidget(main_ok_button)
    buttons_layout.addWidget(main_cancel_button)
    channelSelection_layout.addLayout(buttons_layout)

    # Display
    channelSelection_window.resize(350, 60)
    channelSelection_window.show()


# -----------------------------------------------------------------------------
def clickedOKchanSel(ui):
    geo = mari.geo.current()
    curChannel = [geo.currentChannel()]
    allChannels = geo.channelList()
    selectedPatches = geo.selectedPatches()

    if len(selectedPatches) < 1:
        mari.utils.message("Please select at least one patch and try again.")
    else:
        if currentChannel_button.isChecked():
            main_exec(selectedPatches, curChannel)
        else:
            main_exec(selectedPatches, allChannels)

    #Close Qt dialog
    ui.accept()


# -----------------------------------------------------------------------------
def getLayer(layer_list, layerType="layer", revertToSingleMask=False):
    """Returns a list of all of the layers in the stack including substacks."""

    if layer_list and len(layer_list) > 0:
        for layer in layer_list:

            if hasattr(layer, 'layerStack'):
                layerStack_layers = getLayer(layer.layerStack().layerList(), "layer")
                getLayer(layerStack_layers, "layer")

            if hasattr(layer, 'hasAdjustmentStack') and layer.hasAdjustmentStack():
                adjStack_layers = getLayer(layer.adjustmentStack().layerList(), "mask")
                getLayer(adjStack_layers, "mask")

            if layer.hasMask():
                if not layer.hasMaskStack():  # Quick hack to get the mask, as there is no layer.mask() method.
                    revertToSingleMask = True
                    layer.makeMaskStack()
                    maskStack_layers = [layer.maskStack().layerList()[0]]
                else:
                    maskStack_layers = getLayer(layer.maskStack().layerList(), "mask")
                getLayer(maskStack_layers, "mask")

            clearPatches(layer, layerType, revertToSingleMask)


# -----------------------------------------------------------------------------
def clearPatches(layer, layerType, revertToSingleMask):
    """Fills the patches of the input layer depending on the layer type"""

    layer.makeCurrent()

    if layerType == "layer" and layer.isPaintableLayer():
        fillTransparent.trigger()
        print "    -Filled layer '%s' with transparent." % layer.name()

    elif layerType == "mask" and layer.isPaintableLayer():
        fillBlack.trigger()
        print "    -Filled mask layer '%s' with black." % layer.name()

    if revertToSingleMask:
        flattenMaskGroup.trigger()


# -----------------------------------------------------------------------------
def _registerAction():
    menu_path = "MainWindow/User Scripts/Layers"
    action = mari.actions.create('Clear Selected Patches', 'clearPatchesDialog()')
    # mari.menus.addSeparator(menu_path)
    mari.menus.addAction(action, menu_path)
    action.setShortcut('Ctrl+F')


if mari.app.isRunning():
    _registerAction()
