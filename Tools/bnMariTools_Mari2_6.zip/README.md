bnMariTools
===========

Mari Python:

DESCRIPTION: Scripts for extending The Foundry's Mari painting package. Updates and addtions will be hosted and maintained here on github.

SUPPORTED VERSIONS: 2.5.x

INSTALL INSTRUCTIONS: Copy into "$USER/Mari/Scripts" directory (Create "Scripts" Directory if it is missing).


Email: bneall@gmail.com 

Web: http://bneall.blogspot.com
