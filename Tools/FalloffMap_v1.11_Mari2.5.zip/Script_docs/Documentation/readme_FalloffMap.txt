#----------------------------------------------------------------
Falloff Map
Copyright (c) 2014 Antonio Neto. All Rights Reserved.
#----------------------------------------------------------------                   	
Author: Antonio Neto  
#----------------------------------------------------------------
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
 
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
 
3. Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO,THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY
WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF HE
POSSIBILITY OF SUCH DAMAGE.
#----------------------------------------------------------------

Info: ===============================================================

A Node to add Falloff Effects based on Facing Ratio and Surface\
Luminance
Please note, these effects are non-bakeable. 
When converted to paintable the result will be transparent.
This node is for visual enhancements as well as channel mask purposes.

Requirements: =======================================================

- Mari 2.5 or above


Installation: =======================================================

Take scripts and put them into your user preference script directory.
Or any startup script path that Mari has set. Once these are in 
place, Mari on startup will run through the scripts folder and load
the procedural library. Going to the Python tab and showing the 
console will allow you to see the modules loading up. This is where
if in any case the loading fails it will let you know. 


Example:
	� On Linux+Mac: ~/Mari/Scripts/
	� On Windows: Documents/Mari/Scripts/	


Where to find the nodes: ============================================

The Node will appear under the Custom Folder in the 
/Procedurals/Environment/ Folder


History: ============================================================

# - 3/3/14
    Released v1.0 for Mari 2.5

# - 04/21/14
    Stabilized Paint Baking for Facing Ratio and Shadow/Light Mode

# - 06/18/14
    Depth Mode has been removed due to instabilities

#- 01/27/15
   A new Mode "Perpendicular/Parallel" was added

   Facing Ration Mode was renamed to "Fresnel", a new "Index of Refraction" Setting was added to control Fresnel.

   New Modes "Local Axis X/Y/Z" were added

   A new Mix Curve was added to control the Mix between color A + B




 
        