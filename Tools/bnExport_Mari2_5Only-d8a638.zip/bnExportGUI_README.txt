bnExportGUI README
------------------

How to use:
1. Select the object/channel you wish to export
2. Select the UDIMs in the viewport you wish to export
3. Press the "+" button in the bnExportGUI interface.
4. Set output options and press "Export" button.

Extras:
Pressing the "Delete" key removes selected entries in the list (same as the "-" button).
Doubleclicking a UDIM selects it.
Viewing the console will give output information regarding your export.
Pressing the "Esc" key cancels bake and exits, this make a take a second or two to register.