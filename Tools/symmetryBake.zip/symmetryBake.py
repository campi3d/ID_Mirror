import mari
import PythonQt
core = PythonQt.QtCore

def symmetryBake():


	camera = mari.canvases.current().camera()

	lookAt = camera.lookAt()
	up = camera.up()
	translation = camera.translation()

	paint_buffer = mari.canvases.paintBuffer()
	paint_buffer.bake()
	
	camera.setTranslation( mari.VectorN(-translation.x(),translation.y(),translation.z()))
	camera.setUp( mari.VectorN(-up.x(),up.y(),up.z()))
	camera.setLookAt( mari.VectorN(-lookAt.x(),lookAt.y(),lookAt.z()))

	core = PythonQt.QtCore

	def paintBufferFlip( scaleFactor ):
    		paintBuffer = mari.canvases.paintBuffer()
    		scale = paintBuffer.scale()
    		scale = core.QSizeF( scale.width() * scaleFactor[0], scale.height() * scaleFactor[1] )
    		paintBuffer.setScale( scale )

	paintBufferFlip((-1,1))

	def paintBufferRotate():
            paint_buffer = mari.canvases.paintBuffer()
            rotation = paint_buffer.rotation()
            paint_buffer.setRotation( 360-rotation )

	paintBufferRotate()


	def paintBufferTranslation():

    		paint_buffer = mari.canvases.paintBuffer()
    		translation = paint_buffer.translation()
    		paint_buffer.setTranslation(core.QPointF(-translation.x(), translation.y()))

	paintBufferTranslation()

	paint_buffer = mari.canvases.paintBuffer()
	paint_buffer.bake()

	camera = mari.canvases.current().camera()

	lookAt = camera.lookAt()
	up = camera.up()
	translation = camera.translation()

	camera.setTranslation( mari.VectorN(-translation.x(),translation.y(),translation.z()))
	camera.setUp( mari.VectorN(-up.x(),up.y(),up.z()))
	camera.setLookAt( mari.VectorN(-lookAt.x(),lookAt.y(),lookAt.z()))

	paintBufferFlip((-1,1))

	paintBufferRotate()

	paintBufferTranslation()


actionSymmetryBakeX = mari.actions.create( 'SymmetryBake X', 'symmetryBake()' )

actionSymmetryBakeX.setShortcut("Shift+B")

mari.menus.addAction( actionSymmetryBakeX, "MainWindow/d&eTools/&Symmetry" )



