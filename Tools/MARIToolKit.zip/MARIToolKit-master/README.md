MARIToolKit for MODO 801
===========

MODO KIT to make import of MARI models & textures easier.
This version is for MODO 801 and utilises the new UDIM features of MODO.

## Installation
Copy folder into one of the KIT directories of MODO

Windows:
C:\Users\\(Username)\AppData\Roaming\Luxology\Content\Kits

OS X:
/Library/Application Support/Luxology/Content/Kits
